package day9.ex.tv;

public class TVTest {

	public static void main(String[] args) {
		SaleTV sale = new SaleTV("SALETV-1", 40, 1, 300000);
		RentalTV rent = new RentalTV("RENTALTV-10", 42, 1, 100000);

		sale.channelUp();
		sale.channelUp();

		rent.channelDown();
		rent.channelDown();
		rent.channelDown();

		printAllTv(sale);
		printAllTv(rent);

		printRentalTv(rent);
	}

	static void printAllTv(TV tv) {
		System.out.println(tv.toString());
		if (tv instanceof SaleTV) {
			((SaleTV) tv).play();
			System.out.println();
			((SaleTV) tv).sale();
			System.out.println();
		} else {
			((RentalTV) tv).play();
			System.out.println();
		}

	}

	static void printRentalTv(Rentable tv) {
		((RentalTV) tv).rent();
	}
}
