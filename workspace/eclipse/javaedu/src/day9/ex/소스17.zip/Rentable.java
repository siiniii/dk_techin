package day9.ex.tv;

interface Rentable {
	public void rent();
}
